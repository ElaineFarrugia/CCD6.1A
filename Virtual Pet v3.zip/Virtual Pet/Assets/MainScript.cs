using UnityEngine;
using UnityEngine.UI;

public class MainScript : MonoBehaviour
{
    Dog d; //Dog is a data type    
    Bird b; //Bird is a data type
    public Text dogInfo, birdInfo;
    public Button btnDogPlay, btnDogSleep, btnDogFeed;
    public Button btnBirdPlay, btnBirdSleep, btnBirdFeed;

    // Start is called before the first frame update
    void Start()
    {
        d = new Dog();
        d.name = "Ginger";
        d.age = 1;
        d.happinessLevel = 5;
        d.energyLevel = 5;
        d.barkingLevel = 5;

        b = new Bird();
        b.name = "Skye";
        b.age = 4;
        b.happinessLevel = 5;
        b.energyLevel = 5;
        b.wingSpan = 20;

        btnDogPlay.GetComponent<Button>().onClick.AddListener(dogPlayEvent);
        btnDogFeed.GetComponent<Button>().onClick.AddListener(dogFeedEvent);
        btnDogSleep.GetComponent<Button>().onClick.AddListener(dogSleepEvent);

        btnBirdPlay.GetComponent<Button>().onClick.AddListener(birdPlayEvent);
        btnBirdFeed.GetComponent<Button>().onClick.AddListener(birdFeedEvent);
        btnBirdSleep.GetComponent<Button>().onClick.AddListener(birdSleepEvent);
    }

    void dogPlayEvent()
    {
        d.play();
    }

    void dogFeedEvent()
    {
        d.feed();
    }

    void dogSleepEvent()
    {
        d.sleep();
    }

    void birdPlayEvent()
    {
        b.play();
    }

    void birdFeedEvent()
    {
        b.feed();
    }

    void birdSleepEvent()
    {
        b.sleep();
    }

    // Update is called once per frame
    void Update()
    {
        dogInfo.text = d.GetInfo(); 
        birdInfo.text = b.GetInfo();
    }
}
